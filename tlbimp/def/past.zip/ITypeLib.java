package com4j.tlbimp.def;

import static com4j.NativeType.*;
import com4j.IID;
import com4j.Com4jObject;
import com4j.VTID;
import com4j.ReturnValue;
import com4j.MarshalAs;
import com4j.GUID;
import com4j.Holder;

/**
 * @author Kohsuke Kawaguchi (kk@kohsuke.org)
 */
@IID("{00020402-0000-0000-C000-000000000046}")
public interface ITypeLib extends Com4jObject {
    @VTID(3)
    @ReturnValue(type=HRESULT)
    int getTypeInfoCount();

    @VTID(4)
    /* DEF: @ReturnValue(type=ComObject) */
    ITypeInfo getTypeInfo( /*DEF: @MarshalAs(value=Int32)*/ int index );

    @VTID(5)
    ITypeInfo getTypeInfoOfGuid( /*DEF*/ GUID guid );

//    @VTID(6)
//    TLIBATTR getLibAttr();
//
//    @VTID(7)
//    ITypeComp getTypeComp();

    @VTID(8)
    void getDocumentation( int index, Holder<String> name, Holder<String> docString, Holder<Integer> helpContext, Holder<String> helpFile );

    @VTID(9)
    boolean isName( String name, int reserved );
    @VTID(9)
    boolean isName( StringBuffer name, int reserved );

//    @VTID(10)
//    FindName

//    @VTID(11)
//    ReleaseTLibAttr
}

/*
        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE FindName(
            /* [out][in] -/ LPOLESTR szNameBuf,
            /* [in] -/ ULONG lHashVal,
            /* [length_is][size_is][out] -/ ITypeInfo **ppTInfo,
            /* [length_is][size_is][out] -/ MEMBERID *rgMemId,
            /* [out][in] -/ USHORT *pcFound) = 0;

        virtual /* [local] -/ void STDMETHODCALLTYPE ReleaseTLibAttr(
            /* [in] -/ TLIBATTR *pTLibAttr) = 0;
*/