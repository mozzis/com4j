package com4j.tlbimp.def;

/**
 * @author Kohsuke Kawaguchi (kk@kohsuke.org)
 */
public enum SysKind {
    SYS_WIN16, SYS_WIN32, SYS_MAC, SYS_WIN64
}
