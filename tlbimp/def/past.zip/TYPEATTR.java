package com4j.tlbimp.def;

import com4j.Struct;
import com4j.GUID;

import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * @author Kohsuke Kawaguchi (kk@kohsuke.org)
 */
public class TYPEATTR { // implements Struct {
//    public void unmarshal(byte[] src) {
//        // TODO
//
//    }
//
//    public byte[] marshal() {
//        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//        DataOutput o = new DataOutputStream(baos);
//        try {
//            o.writeLong(guid.l1);
//            o.writeLong(guid.l2);
//            o.writeInt(lcid);
//            o.writeLong(0); // reserved
//            o.writeInt(memidConstructor);
//            o.writeInt(memidDestructor);
//            o.writeInt(0); // lpstrSchema -- reserved
//            o.writeInt(cbSizeInstance);
//            o.writeShort(typekind.code);
//            o.writeShort(cFuncs);
//            o.writeShort(cVars);
//            o.writeShort(cImplTypes);
//            o.writeShort(cbSizeVft);
//            o.writeShort(cbAlignment);
//            o.writeShort(wTypeFlags);
//            o.writeShort(wMajorVerNum);
//            o.writeShort(wMinorVerNum);
//        } catch (IOException e) {
//            // impossible
//            assert false;
//        }
//        return baos.toByteArray();
//    }
//
//
//    GUID guid;
//    int lcid;
//    int memidConstructor;
//    int memidDestructor;
//    int cbSizeInstance;
//    TYPEKIND typekind;
//    short cFuncs;
//    short cVars;
//    short cImplTypes;
//    short cbSizeVft;
//    short cbAlignment;
//    short wTypeFlags;
//    short wMajorVerNum;
//    short wMinorVerNum;
//    TYPEDESC tdescAlias;
//    IDLDESC idldescType;
}
