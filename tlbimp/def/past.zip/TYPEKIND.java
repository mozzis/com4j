package com4j.tlbimp.def;

/**
 * @author Kohsuke Kawaguchi (kk@kohsuke.org)
 */
public enum TYPEKIND {
    ENUM(0),
    RECORD(1),
    MODULE(2),
    INTERFACE(3),
    DISPATCH(4),
    COCLASS(5),
    ALIAS(6),
    UNION(7),
    MAX(8);

    int code;


    TYPEKIND( int code ) {
        this.code = code;
    }
}
