package com4j.tlbimp.def;

import com4j.MarshalAs;
import com4j.NativeType;
import com4j.ReturnValue;
import com4j.tlbimp.def.ITypeLib;

/**
 * TODO: bind to a DLL.
 *
 * @author Kohsuke Kawaguchi (kk@kohsuke.org)
 */
//@Win32DLL("oleaut32.dll")
public interface OleAuto32 {
    @ReturnValue(index=1,type=NativeType.ComObject_ByRef)
    ITypeLib LoadTypeLib(
        @MarshalAs(NativeType.Unicode) String fileName );
}
