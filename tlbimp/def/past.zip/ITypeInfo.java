package com4j.tlbimp.def;

import static com4j.NativeType.HRESULT;
import com4j.IID;
import com4j.Com4jObject;
import com4j.VTID;
import com4j.ReturnValue;
import com4j.MarshalAs;
import com4j.Holder;

/**
 * @author Kohsuke Kawaguchi (kk@kohsuke.org)
 */
@IID("{00020401-0000-0000-C000-000000000046}")
public interface ITypeInfo extends Com4jObject {
    @VTID(3)
    @ReturnValue(type=HRESULT)
    int getTypeInfoCount();

    @VTID(4)
    TYPEATTR getTypeAttr();

//    @VTID(5)
//    ITypeComp getTypeComp();

    @VTID(13)
    void getDocumentation( int memberId, Holder<String> name, Holder<String> docString,
               Holder<Integer> helpContext, Holder<String> helpFile );

}
/*
        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE GetTypeAttr(
            /* [out] -/ TYPEATTR **ppTypeAttr) = 0;
*/
/*
6        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE GetFuncDesc(
            /* [in] -/ UINT index,
            /* [out] -/ FUNCDESC **ppFuncDesc) = 0;

7        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE GetVarDesc(
            /* [in] -/ UINT index,
            /* [out] -/ VARDESC **ppVarDesc) = 0;

8        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE GetNames(
            /* [in] -/ MEMBERID memid,
            /* [length_is][size_is][out] -/ BSTR *rgBstrNames,
            /* [in] -/ UINT cMaxNames,
            /* [out] -/ UINT *pcNames) = 0;

9        virtual HRESULT STDMETHODCALLTYPE GetRefTypeOfImplType(
            /* [in] -/ UINT index,
            /* [out] -/ HREFTYPE *pRefType) = 0;

10        virtual HRESULT STDMETHODCALLTYPE GetImplTypeFlags(
            /* [in] -/ UINT index,
            /* [out] -/ INT *pImplTypeFlags) = 0;

11        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE GetIDsOfNames(
            /* [size_is][in] -/ LPOLESTR *rgszNames,
            /* [in] -/ UINT cNames,
            /* [size_is][out] -/ MEMBERID *pMemId) = 0;

12        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE Invoke(
            /* [in] -/ PVOID pvInstance,
            /* [in] -/ MEMBERID memid,
            /* [in] -/ WORD wFlags,
            /* [out][in] -/ DISPPARAMS *pDispParams,
            /* [out] -/ VARIANT *pVarResult,
            /* [out] -/ EXCEPINFO *pExcepInfo,
            /* [out] -/ UINT *puArgErr) = 0;

13        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE GetDocumentation(
            /* [in] -/ MEMBERID memid,
            /* [out] -/ BSTR *pBstrName,
            /* [out] -/ BSTR *pBstrDocString,
            /* [out] -/ DWORD *pdwHelpContext,
            /* [out] -/ BSTR *pBstrHelpFile) = 0;

        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE GetDllEntry(
            /* [in] -/ MEMBERID memid,
            /* [in] -/ INVOKEKIND invKind,
            /* [out] -/ BSTR *pBstrDllName,
            /* [out] -/ BSTR *pBstrName,
            /* [out] -/ WORD *pwOrdinal) = 0;

        virtual HRESULT STDMETHODCALLTYPE GetRefTypeInfo(
            /* [in] -/ HREFTYPE hRefType,
            /* [out] -/ ITypeInfo **ppTInfo) = 0;

        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE AddressOfMember(
            /* [in] -/ MEMBERID memid,
            /* [in] -/ INVOKEKIND invKind,
            /* [out] -/ PVOID *ppv) = 0;

        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE CreateInstance(
            /* [in] -/ IUnknown *pUnkOuter,
            /* [in] -/ REFIID riid,
            /* [iid_is][out] -/ PVOID *ppvObj) = 0;

        virtual HRESULT STDMETHODCALLTYPE GetMops(
            /* [in] -/ MEMBERID memid,
            /* [out] -/ BSTR *pBstrMops) = 0;

        virtual /* [local] -/ HRESULT STDMETHODCALLTYPE GetContainingTypeLib(
            /* [out] -/ ITypeLib **ppTLib,
            /* [out] -/ UINT *pIndex) = 0;

        virtual /* [local] -/ void STDMETHODCALLTYPE ReleaseTypeAttr(
            /* [in] -/ TYPEATTR *pTypeAttr) = 0;

        virtual /* [local] -/ void STDMETHODCALLTYPE ReleaseFuncDesc(
            /* [in] -/ FUNCDESC *pFuncDesc) = 0;

        virtual /* [local] -/ void STDMETHODCALLTYPE ReleaseVarDesc(
            /* [in] -/ VARDESC *pVarDesc) = 0;
*/